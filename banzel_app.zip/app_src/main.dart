import 'dart:convert';
import 'dart:io' show Platform;
import 'package:flutter/material.dart';
import 'package:pdf/pdf.dart';
import 'package:printing/printing.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:webview_windows/webview_windows.dart' as win;

void main() => runApp(const BanzelApp());

class BanzelApp extends StatelessWidget {
  const BanzelApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'کشوک دوچ',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(colorSchemeSeed: const Color(0xFF1F6FEB), useMaterial3: true),
        locale: const Locale('fa'),
        builder: (c, w) => Directionality(textDirection: TextDirection.rtl, child: w!),
        home: const Root(),
      );
}

class Root extends StatefulWidget {
  const Root({super.key});
  @override
  State<Root> createState() => _RootState();
}

const kServerUrl = 'https://mahroch.ir/cashok/';

class _RootState extends State<Root> {
  @override
  Widget build(BuildContext context) => const Shell(url: kServerUrl);
}

class Shell extends StatelessWidget {
  final String url;
  const Shell({super.key, required this.url});

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Column(children: [
            Container(
              height: 30,
              color: const Color(0xFF16202C),
              padding: const EdgeInsets.symmetric(horizontal: 8),
              child: Row(children: [
                const Text('کشوک دوچ', style: TextStyle(color: Colors.white, fontSize: 13)),
                const Spacer(),
              ]),
            ),
            Expanded(child: Platform.isWindows ? WinView(url: url) : AndroidView(url: url)),
          ]),
        ),
      );
}

// ---------------- اندروید ----------------
class AndroidView extends StatefulWidget {
  final String url;
  const AndroidView({super.key, required this.url});
  @override
  State<AndroidView> createState() => _AndroidViewState();
}

class _AndroidViewState extends State<AndroidView> {
  late final WebViewController ctrl;
  String? error;

  @override
  void initState() {
    super.initState();
    ctrl = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..addJavaScriptChannel('BanzelPrint', onMessageReceived: (m) async {
        try {
          final j = jsonDecode(m.message) as Map<String, dynamic>;
          final mmToPt = 72 / 25.4;
          final w = (j['w'] as num) * mmToPt, h = (j['h'] as num) * mmToPt, mg = (j['m'] as num) * mmToPt;
          await Printing.layoutPdf(
            name: j['title'] as String? ?? 'فاکتور',
            format: PdfPageFormat(w.toDouble(), h.toDouble(), marginAll: mg.toDouble()),
            onLayout: (f) => Printing.convertHtml(format: f, html: j['html'] as String),
          );
        } catch (e) {
          if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('چاپ انجام نشد: $e')));
        }
      })
      ..setNavigationDelegate(NavigationDelegate(
        onWebResourceError: (e) { if (e.isForMainFrame ?? true) setState(() => error = e.description); },
        onPageStarted: (_) => setState(() => error = null),
      ))
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) => error != null
      ? Center(child: Padding(padding: const EdgeInsets.all(20), child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('اتصال به سرور برقرار نشد'), Text(error!, textDirection: TextDirection.ltr, style: const TextStyle(fontSize: 12)),
          const SizedBox(height: 12), FilledButton(onPressed: () { setState(() => error = null); ctrl.loadRequest(Uri.parse(widget.url)); }, child: const Text('تلاش دوباره')),
        ])))
      : WebViewWidget(controller: ctrl);
}

// ---------------- ویندوز ----------------
class WinView extends StatefulWidget {
  final String url;
  const WinView({super.key, required this.url});
  @override
  State<WinView> createState() => _WinViewState();
}

class _WinViewState extends State<WinView> {
  final c = win.WebviewController();
  bool ready = false;
  String? error;

  @override
  void initState() {
    super.initState();
    () async {
      try {
        await c.initialize();
        await c.setBackgroundColor(Colors.white);
        await c.loadUrl(widget.url);
        if (mounted) setState(() => ready = true);
      } catch (e) {
        if (mounted) setState(() => error = '$e');
      }
    }();
  }

  @override
  void dispose() {
    c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (error != null) {
      return Center(child: Padding(padding: const EdgeInsets.all(20), child: Text('خطا در راه‌اندازی WebView2. آن را از سایت مایکروسافت نصب کنید.\n$error', textDirection: TextDirection.ltr)));
    }
    return ready ? win.Webview(c) : const Center(child: CircularProgressIndicator());
  }
}
